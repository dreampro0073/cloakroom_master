<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <ul class="navbar-nav" style="width: 100%;">
        <li class="nav-item">
            <b>M/s New Nabaratna Hospitality Pvt. Ltd.</b> 
        </li>
        <li class="nav-item ml-auto">
            <a href="{{url('logout')}}">Logout</a>
        </li>
    </ul>
</nav>