<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <ul class="navbar-nav" style="width: 100%;">
        <li class="nav-item">
            <b>M/s New Nabaratna Hospitality Pvt. Ltd.</b> 
        </li>
        <li class="nav-item ml-auto">
            <a href="<?php echo e(url('logout')); ?>">Logout</a>
        </li>
    </ul>
</nav><?php /**PATH /Applications/MAMP/htdocs/test/railway_counter/resources/views/admin/page_header.blade.php ENDPATH**/ ?>