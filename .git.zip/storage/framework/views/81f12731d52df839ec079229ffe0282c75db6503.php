<?php $__env->startSection('main'); ?>

<div class="main">
    <h1 class="h3 mb-2 text-gray-800">Dashboard</h1>	
   	

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer_scripts'); ?>
    <?php $version = "0.0.3"; ?>
        
    <script type="text/javascript" src="<?php echo e(url('assets/scripts/core/client_ctrl.js?v='.$version)); ?>" ></script>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/railway_counter_2/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>