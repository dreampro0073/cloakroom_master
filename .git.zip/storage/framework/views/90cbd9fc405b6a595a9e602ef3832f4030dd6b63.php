<?php $__env->startSection('meta'); ?>
	<title>Reset Password</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
	<section>
		<div style="padding-top:32px;">
			<?php if(Session::has('failure')): ?>
				<div class="alert alert-danger">
					<i class="fa fa-ban-circle"></i><strong>Failure!</strong> <?php echo e(Session::get('failure')); ?>

					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			            <img src="<?php echo e(url('front-end/images/cancel.svg')); ?>" width="15px" height="15px" style="margin-top: -12px;">
			        </button>
				</div>
			<?php endif; ?>
			<?php if(Session::has('success')): ?>
				<div class="alert alert-danger">
					<i class="fa fa-ban-circle"></i><strong>Success!</strong> <?php echo e(Session::get('success')); ?>

					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			            <img src="<?php echo e(url('front-end/images/cancel.svg')); ?>" width="15px" height="15px" style="margin-top: -12px;">
			        </button>
				</div>
			<?php endif; ?>
			<?php echo e(Form::open(array('url' => '/admin/reset-password','class' => 'login-form',"method"=>"POST"))); ?>

				<div class="row">
					<div class="col-md-4 form-group ">
						<?php echo e(Form::password('old_password',["class"=>"form-control solid-fill","autocomplete"=>"off","placeholder"=>"Old Password"])); ?>

						<span class="error"><?php echo e($errors->first('old_password')); ?></span>	
					</div>

		
					<div class="col-md-4 form-group ">
						<?php echo e(Form::password('new_password',["class"=>"form-control solid-fill","autocomplete"=>"off","placeholder"=>"New Password"])); ?>

						<span class="error"><?php echo e($errors->first('new_password')); ?></span>
						
					</div>

					<div class="col-md-4 form-group ">
						<?php echo e(Form::password('confirm_password',["class"=>"form-control solid-fill","autocomplete"=>"off","placeholder"=>"Confirm Password"])); ?>

						<span class="error"><?php echo e($errors->first('confirm_password')); ?></span>
						
					</div>
				</div>
				
				

				<?php echo e(csrf_field()); ?>

		        

		        <div class="form-group mt-5">
					<button type="submit" class="btn btn-primary">
			           	Submit
			        </button>
				</div>
			<?php echo e(Form::close()); ?>

		</div>
	</section>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/nnhp_clock/resources/views/admin/users/reset_password.blade.php ENDPATH**/ ?>