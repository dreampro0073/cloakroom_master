<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Title</title>
   <!--  <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/bootstrap-datetimepicker.min.css')); ?>"> -->

    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap3/css/bootstrap.min.css')); ?>">

    <link rel="stylesheet" type="text/css" href="<?php echo e(url('date/bootstrap-time.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/custom.css')); ?>">
</head>
<body  ng-app="app">
	<div id="wrapper">
		<div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                <div class="">
                	<?php echo $__env->yieldContent('main'); ?>
                </div>
             
            </div>
            
        </div>
    </div>
    <script type="text/javascript">
        var base_url = "<?php echo e(url('/')); ?>";
        var CSRF_TOKEN = "<?php echo e(csrf_token()); ?>";
    </script>
    <script type="text/javascript" src="<?php echo e(url('assets/scripts/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('bootstrap3/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('date/bootstrapp-time.min.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(url('assets/scripts/angular.min.js')); ?>" ></script>
    <script type="text/javascript" src="<?php echo e(url('assets/scripts/jcs-auto-validate.js')); ?>" ></script>
    <script type="text/javascript" src="<?php echo e(url('assets/js/custom.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(url('assets/scripts/core/app.js')); ?>" ></script>
    <script type="text/javascript" src="<?php echo e(url('assets/scripts/core/services.js')); ?>" ></script>
    <script type="text/javascript" type="text/javascript" src="<?php echo e(url('assets/scripts/core/dashboard.js')); ?>"></script>
    <script>
      angular.module("app").constant("CSRF_TOKEN", "<?php echo e(csrf_token()); ?>");
    </script>
    <script type="text/javascript">
        $(document).ready(function(){
            $('#timePicker').timepicker({
                minuteStep: 1,
            });
            $('#timePicker2').timepicker({
                minuteStep:1,
            });
        });
    </script>

</body>
</html><?php /**PATH /Applications/MAMP/htdocs/test/railway_counter_2/resources/views/admin/layout.blade.php ENDPATH**/ ?>