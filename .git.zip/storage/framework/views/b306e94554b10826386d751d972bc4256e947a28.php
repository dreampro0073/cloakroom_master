<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>M/s New Nabaratna Hospitality Pvt. Ltd</title>
    <link href="<?php echo e(url('assets/vendor1/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <link href="<?php echo e(url('assets/css/sb-admin-2.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(url('assets/css/custom.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('header_scripts'); ?>
</head>
<body class="bg-gradient-primary">

    <?php echo $__env->yieldContent('main'); ?>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(url('assets/vendor1/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/vendor1/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(url('assets/vendor1/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(url('assets/js/sb-admin-2.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('footer_scripts'); ?>

</body>
</html><?php /**PATH /Applications/MAMP/htdocs/test/railway_counter/resources/views/layout.blade.php ENDPATH**/ ?>