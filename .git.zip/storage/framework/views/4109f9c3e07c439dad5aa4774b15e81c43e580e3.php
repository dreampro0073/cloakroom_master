<?php $__env->startSection('header_scripts'); ?>
 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

<div class="main" ng-controller="dashboardCtrl" ng-init="init();">   
    <div class="card shadow mb-4"> 
       
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_scripts'); ?>
    <?php $version = "0.0.1"; ?>
    <script type="text/javascript" src="<?php echo e(url('assets/scripts/core/dashboard.js?v='.$version)); ?>" ></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/test/railway_counter/resources/views/admin/entries/index.blade.php ENDPATH**/ ?>